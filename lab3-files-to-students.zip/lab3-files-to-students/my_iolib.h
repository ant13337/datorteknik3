extern void inImage();
extern long long getInt();
extern int getText(char *, int);
extern int getInPos();
extern void setInPos(int);

extern void outImage();
extern void putInt(long long);
extern void putText(char *);
extern void putChar(char);
extern int getOutPos();
extern void setOutPos(int);
